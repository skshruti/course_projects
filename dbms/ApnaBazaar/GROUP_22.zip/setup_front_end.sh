pip3 install numpy
pip3 install psycopg2-binary
pip3 install flask
